var sqlMap = {
  // 用户
  testuser: {
    add: 'insert into user values(?,?,?)',
    select:'select * from user where id = ?',
    delete:'delete from user where id = ?',
    update:'update user set name  = ? where id = ?'
  },
  users:{
    add:'insert into user values(?,?,?)',
    select:'select * from user where UserName = ? and password = ?',
    check:'select * from user where UserName = ?',
    addComment1:'insert into comment(UserName,Mid,MedicineC,MCDate) value(?,?,?,?)',
    getComment1:'select * from comment where Mid = ?',
    addConnection:'insert into collectionlink values(?,?)',
    getConnection:'select * from collectionlink where UserName = ?',
    getMedicine:'select * from medicine where Mid = ?',
    deleteM:'DELETE from collectionlink where UserName = ? and Mid = ?',
    addUser:'insert into userinfo(UserName) values(?)',
    setUINFO:'update userinfo set sex = ?,phone = ?,name = ?,xin = ?,email = ? where UserName = ?',
    getUInfo:'select * from userinfo where UserName = ?'
  },

  /*
  reader: {
    add: 'insert into reader(name) values (?)',
    delete: 'delete from reader where name = ?',
    search: 'select * from reader where name = ?', //查找读者信息
    borrowBook: 'update reader set lendBook1 = ? where name = ?'//更新用户表中的已借阅书籍
  },
  book: {
    add: 'insert into book(name, author, stock) values (?, ?, ?)',
    search: 'select * from book where name = ?',
    borrowBook: 'update book set stock = ? , lendNum = ? where name = ?'//更新书籍表中的库存
  },
   */

  test:{
    select: 'select * from test where id = ?'
  }
}
module.exports = sqlMap;
