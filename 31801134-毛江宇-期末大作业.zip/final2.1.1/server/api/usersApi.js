var models = require('../db')
var express = require('express')
var router = express.Router()
var mysql = require('mysql')
var $sql = require('../sqlMap')

// 连接数据库
var conn = mysql.createConnection(models.mysql)

conn.connect()
var jsonWrite = function (res, ret) {
  if (typeof ret === 'undefined') {
    res.json({
      code: '1',
      msg: '操作失败'
    })
  } else {
    res.json(ret)
  }
}

//注册用户接口
router.post('/addUser', (req, res) => {
  var sql = $sql.users.add;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.name,params.password,params.date], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})

//登录用户接口
router.get('/login', (req, res) => {
  var sql = $sql.users.select
  var params = req.query
  console.log(params)
  conn.query(sql, [params.name,params.password], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//注册时检查用户是否重名接口
router.get('/check', (req, res) => {
  var sql = $sql.users.check
  var params = req.query
  console.log(params)
  conn.query(sql, [params.name], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//获取评论接口
router.get('/getComment1', (req, res) => {
  var sql = $sql.users.getComment1
  var params = req.query
  console.log(params)
  conn.query(sql, [params.id], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//获取收藏接口
router.get('/getCC', (req, res) => {
  var sql = $sql.users.getConnection
  var params = req.query
  console.log(params)
  conn.query(sql, [params.name], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//获取所有药名接口
router.get('/getM', (req, res) => {
  var sql = $sql.users.getMedicine
  var params = req.query
  console.log(params)
  conn.query(sql, [params.id], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//获取用户个人信息接口
router.get('/getUINFO', (req, res) => {
  var sql = $sql.users.getUInfo
  var params = req.query
  console.log(params)
  conn.query(sql, [params.name], function (err, result) {
    if (err) {
      console.log(err)
    }
    if (result) {
      console.log(result)
      res.send(result)
    }
  })
})

//增加评论接口
router.post('/addMC', (req, res) => {
  var sql = $sql.users.addComment1;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.name,params.MID,params.MC,params.date], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})

//增加收藏接口
router.post('/addCC', (req, res) => {
  var sql = $sql.users.addConnection;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.name,params.MID], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})

//取消收藏接口
router.post('/deleteM', (req, res) => {
  var sql = $sql.users.deleteM;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.name,params.MID], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})

//注册时初始化用户信息接口
router.post('/createUinfo', (req, res) => {
  var sql = $sql.users.addUser;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.name], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})

//更新用户信息接口
router.post('/setUinfo', (req, res) => {
  var sql = $sql.users.setUINFO;
  var params = req.body;
  console.log(params);
  conn.query(sql, [params.sex,params.phone,params.ming,params.xin,params.email,params.name], function(err, result) {
    if (err) {
      console.log(err);
    }
    if (result) {
      jsonWrite(res, result);
    }
  })
})
module.exports = router
