module.exports = {
  mysql: {
    host: '127.0.0.1',//mysql连接ip地址
    user: 'root',
    password: 'qq1220',//mySql用户名密码
    database: 'js',//mySql数据库名
    port: '3306'//mysql连接端口
  }
}
