<template>
  <el-carousel :interval="4000" type="card" height="75px" indicator-position="none">
    <el-carousel-item v-for="item in picture" :key="item.name">
      <img :src="item.src">
    </el-carousel-item>
  </el-carousel>
</template>

<script>
export default {
  name: "pictureRun",
  props:['picture'],
  data(){
    return{

    }
  }
}
</script>

<style scoped>
.el-carousel__item h3 {
  color: #ffffff;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: transparent;
}

.el-carousel__item:nth-child(2n+1) {
  background-color: transparent;
}
</style>
