<template>
  <el-tabs v-model="activeName" @tab-click="handleClick" style="height: 200px">
    <el-tab-pane label="A" name="first">
      <div style="border-bottom: 1px solid #1f8b00">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">阿魏</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">安息香</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">艾叶</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">矮地茶</div></el-col>
        </el-row>
      </div>
    </el-tab-pane>
    <el-tab-pane label="B" name="second">
      <div style="border-bottom: 1px solid #1f8b00">
        <el-row :gutter="1" style="margin-top: 10%;background: #ffffff">
          <el-col :span="6" style="margin-top: -5%;background: #ffffff"><div class="grid-content bg-purple" style="background: #ffffff">白屈菜</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">板蓝根</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白苏子</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白芥子</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白兰花</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白药子</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白首乌</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">八角枫</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白豆根</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白头翁</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">白石花</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">八楞木</div></el-col>
        </el-row>
      </div>
    </el-tab-pane>
    <el-tab-pane label="C" name="third">
      <div style="border-bottom: 1px solid #1f8b00">
        <el-row :gutter="1" style="margin-top: 10%;background: #ffffff">
          <el-col :span="6" style="margin-top: -5%;background: #ffffff"><div class="grid-content bg-purple" style="background: #ffffff">臭牡丹</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">川续断</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">澄茄子</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">穿山甲</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">翠云草</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">赤石脂</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">草乌叶</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">柴胡</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">穿破石</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">沉香</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">臭梧桐</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">春不见</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">磁石</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">蟾酥</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">蝉蜕</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">蚕沙</div></el-col>
        </el-row>
      </div>
    </el-tab-pane>
    <el-tab-pane label="D" name="fourth">
      <div style="border-bottom: 1px solid #1f8b00">
        <el-row :gutter="1" style="margin-top: 10%;background: #ffffff">
          <el-col :span="6" style="margin-top: -5%;background: #ffffff"><div class="grid-content bg-purple" style="background: #ffffff">独脚金</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">独一味</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">地榆</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">当归</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">豆豉姜</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">大血藤</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">大黄</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">冬葵子</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">丁工藤</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">地骨皮</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">地枫皮</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">大青叶</div></el-col>
        </el-row>
      </div>
      <div style="border-bottom: 1px solid #1f8b00;margin-top: 15%">
        <el-row :gutter="1" style="margin-top: 10%;">
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">淡竹叶</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">丁香</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">断血流</div></el-col>
          <el-col :span="6" style="margin-top: -5%"><div class="grid-content bg-purple" style="background: #ffffff">冬葵果</div></el-col>
        </el-row>
      </div>
    </el-tab-pane>
  </el-tabs>
</template>

<script>
export default {
  data() {
    return {
      activeName: 'first'
    };
  },
  methods: {
    handleClick(tab, event) {
      //console.log(tab, event);
    }
  }
};
</script>

<style scoped>
.el-row {
  margin-bottom: 0px;}
.el-row:last-child {
   margin-bottom: 0;
 }
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #ffffff;
}
.bg-purple {
  background: #ffffff;
}
.bg-purple-light {
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 20px;

}
.row-bg {
  padding: 10px 0;
  background-color: #ffffff;
}


</style>
