<template>
<div>
  <div style="margin-top: 5%" @click="dialogVisible = true">
    <el-container style="height: 100px">
      <el-image :src="books.url"></el-image>
      <el-main style="margin-top: -10%;width: 60%;margin: auto">
        <h5 style="margin-top: 20%;width: 110px">《{{books.name}}》</h5>
      </el-main>
    </el-container>
    <el-divider></el-divider>
  </div>
  <div>
    <el-dialog style="border-radius: 50px;text-align: center"
      :title="books.name"
      :visible.sync="dialogVisible"
      width="80%">
      <el-image :src="books.url"></el-image>
      <div v-html="books.text"></div>
    </el-dialog>
  </div>

</div>
</template>

<script>
export default {
name: "bookbar",
  props:['books'],
  data() {
    return {
      dialogVisible: false
    };
  },
  methods: {
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    }
  }
}
</script>

<style scoped>
.el-main {
  background-color: #f0ffff;
  color: #333;
  line-height: 5%;
}
.abow_dialog {
  display: flex;
  justify-content: center;
  align-items: Center;
  overflow: hidden;
.el-dialog {
  margin: 0 auto !important;
  height: 90%;
  overflow: hidden;
.el-dialog__body {
  position: absolute;
  left: 0;
  top: 54px;
  bottom: 0;
  right: 0;
  padding: 0;
  z-index: 1;
  overflow: hidden;
  overflow-y: auto;
}
}
}
</style>
