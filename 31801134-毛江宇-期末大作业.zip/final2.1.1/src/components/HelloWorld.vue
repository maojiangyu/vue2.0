<template>
  <div style="background: #fff;width: 100%;" v-cloak>
    <welcome style="height: 30px" title-message="欢迎来到中药网"></welcome>
    <NagtiveBar @activity="getActivity" style="margin-top: 2%" ></NagtiveBar>
    <div v-show="activity===1">
      <div style="margin-top: 2%"><el-container>

        <el-header style="margin-top: 1%;">
          <picture-run v-bind:picture="picture"></picture-run>
        </el-header>
        <el-container class="layout-container" style="margin-top: 5%">
          <el-aside width="28%" style="height: 250px">
            <div style="margin-bottom: 20%">
              <h6>中药功效分类查找</h6>
              <popver-one></popver-one>
              <div style="margin-top: 5%">
                <qingre></qingre>
              </div>
              <div style="margin-top: 5%"><bu-xu></bu-xu></div>
              <div style="margin-top: 5%"><zhi-xue></zhi-xue></div>
            </div>
          </el-aside>
          <el-container>
            <el-main style="width: auto;height: 250px">
              <div style="margin-top:-8%;border-top: 1px solid #ff6e01;margin-left: -5%;background: #fde0c4;height: 15%;width: 110%;color: #ff6e01">
                <div style="margin-top: 5%;font-size: small">热门药草</div>
              </div>
              <hot-medicine v-bind:medicine="medicineInfoList"></hot-medicine>
              <hot-medicine v-bind:medicine="medicineInfoList"></hot-medicine>
              <hot-medicine v-bind:medicine="medicineInfoList"></hot-medicine>
            </el-main>
          </el-container>
        </el-container>
      </el-container></div>
      <div style="margin-top: 1%">
        <news-bar></news-bar>
      </div>
      <div><el-container style="margin-top: 1%">
        <el-container>
          <el-aside width="28%">
            <h4 style="margin-top: 8%">
              药物大全
            </h4>
            <div>

            </div>
          </el-aside>
          <el-container>
            <el-main>
              <div style="margin-top: -10%;">
                <searchBar></searchBar>
              </div></el-main>
          </el-container>
        </el-container>
      </el-container></div>
    </div>
    <div v-show="activity===2"><xue-wei></xue-wei></div>
    <div v-show="activity===3"><eat-index></eat-index></div>
    <div v-show="activity===4"><help></help></div>
  </div>

</template>

<script>
import NagtiveBar from "./NagtiveBar";
import PopverOne from "./firstPopverButton/PopverOne";
import Qingre from "./firstPopverButton/Qingre";
import BuXu from "./firstPopverButton/BuXu";
import ZhiXue from "./firstPopverButton/ZhiXue";
import searchBar from "./searchBar";
import PictureRun from "./pictureRun";
import Welcome from "./welcome";
import NewsBar from "./newsBar";
import EatIndex from "./Main3/eatIndex";
import XueWei from "./XueWei";
import Help from "./help";
import HotMedicine from "./hotMedicine";
export default {
  name: 'HelloWorld',
  components: {
    HotMedicine,
    Help,
    XueWei, EatIndex, NewsBar, Welcome, PictureRun, ZhiXue, BuXu, Qingre, PopverOne, NagtiveBar,searchBar},
  data(){
    return {
      picture:[
      {
        name:1,
        src:require('@/assets/img/麦冬.png'),
      },
      {
        name:2,
        src: require('@/assets/img/板蓝根.png')
      },
      {
        name:3,
        src: require('@/assets/img/天山雪莲.png')
      },
      {
        name:4,
        src: require('@/assets/img/燕窝.png')
      },
      {
        name:5,
        src: require('@/assets/img/西洋参.png')
      }

    ],
      medicineInfoList:[
        {
          id:1,
          name:'麦冬',
          url:require('@/assets/img/麦冬.png'),
          title:'麦冬的功效:',
          effect:'麦冬的好处...',
          describe:'<p>麦冬以块根入中药。地</p>' +
            '<p style="margin-top: 10%">下具细长匍匐枝，须根</p><p style="margin-top: 10%">' +
            '常有部分膨大成肉质的</p><p style="margin-top: 10%">块根。麦冬挖起后，剪</p><p style="margin-top: 10%">下块根，蒸发水气晒干' +
            '</p><p style="margin-top: 10%">，麦冬的功效与作用：</p><p style="margin-top: 10%">养阴生津、润肺清心。</p>'
        },
        {
          id:2,
          name:'连翘',
          title:'连翘的功效:',
          effect: '连翘的好处...',
          url:require('@/assets/img/连翘.png'),
          describe:'<p>落叶灌木，高2~3米</p>' +
            '<p style="margin-top: 10%">。枝条细长开展或下垂</p><p style="margin-top: 10%">' +
            '，小枝浅棕色。生于低</p><p style="margin-top: 10%">山灌丛或林缘。分布于</p><p style="margin-top: 10%">河北、山西、陕西等地' + '</p>',
        },
        {
          id:3,
          name:'绞股蓝',
          title:'绞股蓝的功效:',
          effect: '绞股蓝的好处...',
          url: require('@/assets/img/绞股蓝.png'),
          describe: '<p></p>' +
            '<p style="margin-top: 10%">多年生草质藤本，茎纤</p><p style="margin-top: 10%">' +
            '细，灰棕色至暗棕色，</p><p style="margin-top: 10%">表面具纵沟纹，侧生小</p><p style="margin-top: 10%">叶卵状长圆形或长圆状' +
            '</p><p style="margin-top: 10%">披针形</p>',
        }
      ],
      activity:1
    }
  },
  methods:{
    getActivity(data){
      this.activity = data;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style >
[v-cloak]{
  display: none;
}
.el-header, .el-footer {
  background-color: #ffffff;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #DDFFBC;
  color: #333;
  text-align: center;
  border-radius: 5px
}

.el-main {
  background-color: #f7fcff;
  color: #333;
  line-height: 5%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
.layout-container {
  height: 100%;
}

</style>
