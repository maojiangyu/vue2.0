<template>
  <div>
    <el-container style="margin-top: 1%;height: 200px">

      <el-container v-cloak>
        <el-aside width="28%">
          <div style="margin-top: 15%">
            <el-button style="margin-top: 5%;border: none;background: #DDFFBC;color: #52734D" @click="shownew">新闻速报</el-button>
          </div>
          <div style="margin-top: 15%">
            <el-button style="border: none;background: #DDFFBC;color: #52734D" @click="showBook">古籍查询</el-button>
          </div>
          <div style="margin-top: 15%">
            <el-button style="border: none;background: #DDFFBC;color: #52734D" @click="showCulture">中医养生</el-button>
          </div>
        </el-aside>
          <el-container>
            <el-main style="height: 200px">
              <div v-cloak>
                <transition name="el-fade-in">
                  <div v-show="activeKey===1">
                    <div>
                      <h4 style="margin-top: 5%;margin-bottom: 7%;margin-left: 2%">今日新闻</h4>
                      <div style="margin-bottom: 10%;height: 10px;background: #ff6e01;border-radius: 5px">
                      </div>
                      <div>
                        <span style="font-size: small">济南打造“智慧中药房”</span>
                        <el-divider></el-divider>
                        <span style="font-size: small">4味中药尽量少服用</span>
                        <el-divider></el-divider>
                        <span style="font-size: small">云南丽江“土”专家的中药情</span>
                        <el-divider></el-divider>
                        <div v-html="content"></div>
                        <el-divider></el-divider>
                        <span style="font-size: small">孙春兰：推动中医药早介入早干预</span>
                      </div>
                    </div>
                  </div>
                </transition>
                <transition name="el-fade-in">
                  <div v-show="activeKey===2">
                    <div style="margin-top: -8%"></div>
                    <bookbar v-bind:books="book1"></bookbar>
                    <bookbar v-bind:books="book2"></bookbar>
                    <bookbar v-bind:books="book3"></bookbar>
                    <bookbar v-bind:books="book1"></bookbar>
                    <bookbar v-bind:books="book2"></bookbar>
                    <bookbar v-bind:books="book3"></bookbar>
                  </div>
                </transition>
                <transition name="el-fade-in">
                  <div v-show="activeKey===3">
                    <y-main></y-main>
                  </div>
                </transition>
              </div>

            </el-main>
          </el-container>

      </el-container>
    </el-container>
  </div>
</template>

<script>
import YMain from "./yangsheng/YMain";
import Bookbar from "./bookbar";
export default {
  name: "newsBar",
  components: {Bookbar, YMain},
  data(){
    return{
      activeKey:1,
      book1:{
        name:'本草纲目',
        url:require('../assets/img/本草纲目.png'),
        text:'<p style="margin-top: 10%">其中以部为“纲”，以类为“目”，</p>' +
          '<p style="margin-top: 10%">计分16部(水、火、土、金石、</p>' +
          '<p style="margin-top: 10%">草、谷、菜、果、木、服器、虫、</p>' +
          '<p style="margin-top: 10%">鳞、介、禽、兽、人)60类。各部按</p>' +
          '<p style="margin-top: 10%">“从微至巨”、“从贱至贵”，既便检</p>' +
          '<p style="margin-top: 10%">索，又体现出生物进化发展思想。</p>'
      },
      book2:{
        name:'神农本草经',
        url:require('../assets/img/神农本草经.png'),
        text:'<p style="margin-top: 10%">《神农本草经》全书分三卷，载药3</p>' +
          '<p style="margin-top: 10%">65种，以三品分类法，分上、中、</p>' +
          '<p style="margin-top: 10%">下三品，文字简练古朴，成为中药理</p>' +
          '<p style="margin-top: 10%">论精髓。《神农本草经》记载了36</p>' +
          '<p style="margin-top: 10%">5种药物的疗效，多数真实可靠，至</p>' +
          '<p style="margin-top: 10%">今仍是临床常用药</p>'
      },
      book3:{
        name:'新修本草',
        url:require('../assets/img/新修本草.png'),
        text:'<p style="margin-top: 10%">《药图》25卷，目录1卷；《图</p>' +
          '<p style="margin-top: 10%">经》7卷。正文实际载药850种，</p>' +
          '<p style="margin-top: 10%">较《本草经集注》新增114种。此</p>' +
          '<p style="margin-top: 10%">书以《本草经集注》为基础，增补</p>' +
          '<p style="margin-top: 10%">注文与新药。又将原草木、虫兽2类</p>' +
          '<p style="margin-top: 10%">，析为草、木、禽兽、虫鱼4类，序</p><p style="margin-top: 10%">例亦一分为二</p>。'
      },
      booklist:[
        {
          id:1,
          name:'本草纲目',
          text:'<p style="margin-top: 10%">其中以部为“纲”</p><p style="margin-top: 10%">，以类为“目”，</p>' +
            '<p style="margin-top: 10%">计分16部(水、</p>' +
            '<p style="margin-top: 10%">火、土、金石、</p>' +
            '<p style="margin-top: 10%">草、谷、菜、果、</p><p style="margin-top: 10%">木、服器、虫、鳞</p>' +
            '<p style="margin-top: 10%">、介、禽、兽、人</p>' +
            '<p style="margin-top: 10%">)60类。各部按“</p><p style="margin-top: 10%">从微至巨”、“从</p>' +
            '<p style="margin-top: 10%">贱至贵”，既便</p><p style="margin-top: 10%">检索，又体现出生</p>' +
            '<p style="margin-top: 10%">物进化发展思想。</p>'
        },
        {
          id:2,
          name:'神农本草经',
          text:'<p style="margin-top: 10%">《神农本草经》全</p>' +
            '<p style="margin-top: 10%">书分三卷，载药3</p>' +
            '<p style="margin-top: 10%">65种，以三品分</p>' +
            '<p style="margin-top: 10%">类法，分上、中、</p>' +
            '<p style="margin-top: 10%">下三品，文字简练</p>' +
            '<p style="margin-top: 10%">古朴，成为中药理</p>' +
            '<p style="margin-top: 10%">论精髓。《神农本</p>' +
            '<p style="margin-top: 10%">草经》记载了36</p>' +
            '<p style="margin-top: 10%">5种药物的疗效，</p>' +
            '<p style="margin-top: 10%">多数真实可靠，至</p>' +
            '<p style="margin-top: 10%">今仍是临床常用药</p>'
        },
        {
          id:3,
          name:'新修本草',
          text:'<p style="margin-top: 10%">《药图》25卷，</p>' +
            '<p style="margin-top: 10%">目录1卷；《图</p>' +
            '<p style="margin-top: 10%">经》7卷。正文实</p>' +
            '<p style="margin-top: 10%">际载药850种，</p>' +
            '<p style="margin-top: 10%">较《本草经集注》</p>' +
            '<p style="margin-top: 10%">新增114种。此</p>' +
            '<p style="margin-top: 10%">书以《本草经集</p>' +
            '<p style="margin-top: 10%">注》为基础，增补</p>' +
            '<p style="margin-top: 10%">注文与新药。又将</p>' +
            '<p style="margin-top: 10%">原草木、虫兽2类</p>' +
            '<p style="margin-top: 10%">，析为草、木、禽</p>' +
            '<p style="margin-top: 10%">兽、虫鱼4类，序</p><p style="margin-top: 10%">例亦一分为二</p>。'
        }
      ],
      content:'<div><span style="font-size: small">坚持中西医并重，实施中医药振兴发</span></div><div style="margin-top: 20px"><span style="font-size: small">展重大工程</span></div>'
    }
  },
  methods:{
    shownew(){
      this.activeKey = 1
    },
    showBook(){
      this.activeKey = 2
    },
    showCulture(){
      this.activeKey = 3
    },
    goTo(id){
      if(id == 1)
        this.$router.push({path: '/newsBar'})
      else if (id == 2)
        console.log(2)
      else if (id == 3)
        console.log(3)
    }
  }
}
</script>

<style scoped>
[v-cloak] {
  display: none;
}
.el-header, .el-footer {
  background-color: #ffffff;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #DDFFBC;
  color: #333;
  text-align: center;
  border-radius: 5px
}

.el-main {
  background-color: #f0ffff;
  color: #333;
  line-height: 5%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
.layout-container {
  height: 100%;
}

</style>
