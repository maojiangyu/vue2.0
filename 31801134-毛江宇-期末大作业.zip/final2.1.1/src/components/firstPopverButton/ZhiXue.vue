<template>
  <el-popover
    placement="top-start"
    width="300"
    trigger="click"
  >
    <div style="margin-top: 2%">
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">化痰止瘀</el-col>
        <el-col :span="6">珠子参</el-col>
        <el-col :span="6">莲房</el-col>
        <el-col :span="6">三七</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">凉血止血</el-col>
        <el-col :span="6">地榆</el-col>
        <el-col :span="6">白石花</el-col>
        <el-col :span="6">木耳</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">收敛止血</el-col>
        <el-col :span="6">红药子</el-col>
        <el-col :span="6">血余炭</el-col>
        <el-col :span="6">虫白蜡</el-col>
      </el-row>
    </div>
    <el-button slot="reference" style="width: 90%;border: none"><div style="text-align: center;color: #91C788;font-weight: bolder">止血药</div></el-button>
  </el-popover>
</template>

<script>
export default {
  name: "ZhiXue",
  data() {
    return {
      visible: false
    };
  }
}
</script>

<style scoped>

</style>
