<template>
  <el-popover
    placement="top-start"
    width="300"
    trigger="click"
    >
    <div style="margin-top: 2%">
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">温化寒痰</el-col>
        <el-col :span="6" ><div @click="goTo(1)">华山参</div></el-col>
        <el-col :span="6"><div @click="goTo(2)">猫爪草</div></el-col>
        <el-col :span="6"><div @click="goTo(3)">天南星</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">清化热痰</el-col>
        <el-col :span="6"><div @click="goTo(5)">海浮石</div></el-col>
        <el-col :span="6"><div @click="goTo(4)">暴马丁香</div></el-col>
        <el-col :span="6"><div @click="goTo(6)">海蛤壳</div></el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">止咳平喘</el-col>
        <el-col :span="6">白屈菜</el-col>
        <el-col :span="6">猪胆粉</el-col>
        <el-col :span="6">白兰花</el-col>
      </el-row>
    </div>
    <el-button slot="reference" style="width: 90%;border: none"><div style="text-align: center;color: #91C788;font-weight: bolder">化痰止咳</div></el-button>
  </el-popover>
</template>

<script>
export default {
  name: "PopverOne",
  data() {
    return {
      visible: false
    };
  },
  methods:{
    goTo(id){
      if(id==1){
        this.$router.push({path:'/HuaShanShen'})
      }else if (id==2){
        this.$router.push({path:'/MaoZhuaCao'})
      } else if (id==3){
        this.$router.push({path:'/TianNanXing'})
      }else if (id==4){
        this.$router.push({path:'/baoMaDingXiang'})
      }else if (id==5){
        this.$router.push({path:'/haiFuShi'})
      }else if (id==6){
        this.$router.push({path:'/haiGeKe'})
      }
    }
  }
}
</script>

<style scoped>

</style>
