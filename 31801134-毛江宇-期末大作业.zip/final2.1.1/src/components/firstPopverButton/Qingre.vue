<template>
  <el-popover
    placement="top-start"
    width="300"
    trigger="click"
    >
    <div style="margin-top: 2%">
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">清虚热药</el-col>
        <el-col :span="6">青嵩</el-col>
        <el-col :span="6">浮小麦</el-col>
        <el-col :span="6">胡黄连</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">清热解毒</el-col>
        <el-col :span="6">仙人掌</el-col>
        <el-col :span="6">吉祥草</el-col>
        <el-col :span="6">臭牡丹</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">清热凉血</el-col>
        <el-col :span="6">玄参</el-col>
        <el-col :span="6">白头翁</el-col>
        <el-col :span="6">玉叶金花</el-col>
      </el-row>
    </div>
    <el-button slot="reference" style="width: 90%;border: none"><div style="text-align: center;color: #91C788;font-weight: bolder">清热药</div></el-button>
  </el-popover>
</template>

<script>
export default {
  name: "Qingre",
  data() {
    return {
      visible: false
    };
  }
}
</script>

<style>
.el-row {
  margin-bottom: 2%;
}
.el-row :last-child {
   margin-bottom: 0;
 }

.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>
