<template>
  <el-popover
    placement="top-start"
    width="300"
    trigger="click"
    >
    <div style="margin-top: 2%">
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">补气药</el-col>
        <el-col :span="6" >甘草</el-col>
        <el-col :span="6">竹节参</el-col>
        <el-col :span="6">西洋参</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">补阳药</el-col>
        <el-col :span="6">淫羊菌</el-col>
        <el-col :span="6">海马</el-col>
        <el-col :span="6">天山雪莲</el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="6" style="font-weight: bolder;color: black">补阴药</el-col>
        <el-col :span="6">龟甲</el-col>
        <el-col :span="6">燕窝</el-col>
        <el-col :span="6">蓝布正</el-col>
      </el-row>
    </div>
    <el-button slot="reference" style="width: 90%;border: none;"><div style="text-align: center;color: #91C788;font-weight: bolder">补虚药</div></el-button>
  </el-popover>
</template>

<script>
export default {
  name: "BuXu",
  data() {
    return {
      visible: false
    };
  },
  methods:{

  }

}
</script>

<style scoped>

</style>
