<template>
<div>
  <div style="margin-top: 3%">
    <el-row :gutter="2" style="height: 100px">
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">中药</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">养生</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">内科</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">外科</div>
      </div></el-col>
    </el-row>
  </div>
  <div style="margin-top: 1%">
    <el-row :gutter="2" style="height: 100px">
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">儿科</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">妇科</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">男科</div>
      </div></el-col>
      <el-col :span="6"><div style="text-align: center">
        <el-image :src="require('@/assets/img/help.png')"></el-image>
        <div style="text-align: center">骨科</div>
      </div></el-col>
    </el-row>
  </div>
  <el-divider></el-divider>
  <div>
    <h3 style="margin-left: 5%">我的咨询记录</h3>
  </div>
  <el-divider></el-divider>

  <div style="margin-top: 2%;box-shadow:0.5px 0.5px 5px #000;width: 350px;margin-left: 2%;border-radius: 2px" v-for="(item,index) in list" :key="index">
    <p style="margin-left: 5%">Q: {{item.Q}}</p>
    <p style="margin-left: 5%">A: {{item.A}}</p>
  </div>

</div>
</template>

<script>
export default {
  name: "help",
  data(){
    return{
      list:[
        {
          Q: '头疼怎么办',
          A: '多喝热水'
        },
        {
          Q: '感冒怎么办',
          A: '多喝热水'
        },
        {
          Q: '中药好苦啊',
          A: '加油'
        },
        {
          Q: '腿疼怎么办',
          A: '多喝热水'
        },
        {
          Q: '中暑怎么办',
          A: '多喝热水'
        },
      ]
    }
  }
}
</script>

<style scoped>

</style>
