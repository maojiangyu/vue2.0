<template>
  <div>
    <div v-for="item in medicine" :key="item.id" @click="open1(item)">
      <div style="margin-left: -5%;margin-top: 1%;">
        <el-container>
          <div style="margin-top: 20%;margin: auto">
            <el-image :src="item.url"></el-image>
            <h6 style="margin-left: 30%;margin-top: 15%">{{item.name}}</h6>
          </div>
          <el-main style="width: 100%;margin-left: -5%;margin-top: 0;margin: auto">
            <div v-html="item.describe" style="font-size: small"></div>
          </el-main>
        </el-container>
      </div>
    </div>
  </div>


</template>

<script>
export default {
name: "hotMedicine",
  props:['medicine'],
  methods:{
    open1(item) {
      const h = this.$createElement;

      this.$notify({
        title: item.effect,
        message: h('i', { style: 'color: teal'}, item.effect)
      });
    },
  }
}
</script>

<style scoped>

</style>
