<template>
  <el-row :gutter="10">
    <el-col :span="6"><div class="grid-content bg-purple" ><div style="font-size: small;color: #52734D;background: #c3dcb7;height: 25px" @click="getActivity(1)">中药首页</div></div></el-col>
    <el-col :span="6"><div class="grid-content bg-purple" ><div style="font-size: small;color: #52734D;background: #c3dcb7;height: 25px" @click="getActivity(4)">帮助咨询</div></div></el-col>
    <el-col :span="6"><div class="grid-content bg-purple" ><div style="font-size: small;color: #52734D;background: #c3dcb7;height: 25px" @click="getActivity(2)">针灸穴位</div></div></el-col>
    <el-col :span="6"><div class="grid-content bg-purple" ><div style="font-size: small;color: #52734D;background: #c3dcb7;height: 25px" @click="getActivity(3)">药膳食疗</div></div></el-col>
  </el-row>
</template>

<script>
export default {
name: "NagtiveBar",
  methods:{
    getActivity(id){
      this.$emit('activity',id);
    }
  }
}
</script>

<style scoped>
.el-row {
  margin-bottom: 0px;
  text-align: center;
}
.el-row :last-child {
  margin-bottom: 0;
  text-align: center;
 }
.el-col {
  border-radius: 4px;
  background: #c3dcb7
}
.bg-purple-dark {
  background: #c3dcb7
}
.bg-purple {
  background: #c3dcb7
}
.bg-purple-light {
  background: #c3dcb7

}
.grid-content {
  border-radius: 4px;
  min-height: 30px;
  text-align: center;
  background: #c3dcb7
}
.row-bg {
  padding: 10px 0;
  background: #ffffff
}
</style>
