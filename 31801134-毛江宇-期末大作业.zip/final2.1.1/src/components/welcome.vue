<template>
<div style="height: 30px">
  <h3 class="welText">{{titleMessage}}</h3>
  <div class="login">
    <div v-show="activeKey===1">
      <el-button @click="clickLogin" style="background: #91C788;font-weight: bolder;border: none">登录</el-button>
      <el-button @click="clickRegister" style="font-weight: bolder">注册</el-button>
      <el-dialog title="登录" :visible.sync="dialogVisible" width="80%" style="border-radius: 10px" :append-to-body="true">
        <div slot="footer" class="dialog-footer">
          <div style="margin-top: -25%">
            <div class="demo-input-suffix" style="text-align: center;margin-bottom: 5%;">
              用户名：
              <el-input
                placeholder="请输入用户名"
                v-model="input1" style="width: 50%">
              </el-input>
            </div>
          </div>
          <div>
            <div class="demo-input-suffix" style="text-align: center;margin-left: 6%;margin-bottom: 7%;">
              密码：
              <el-input
                placeholder="请输入密码"
                v-model="input2" style="width: 53%" :show-password="true">
              </el-input>
            </div>
          </div>
          <el-button @click="loginClose">取 消</el-button>
          <el-button type="primary" @click="login">确 定</el-button>
        </div>
      </el-dialog>
      <el-dialog title="注册" :visible.sync="dialogVisible2" width="80%" style="border-radius: 10px;" :append-to-body="true">
        <div slot="footer" class="dialog-footer">
          <div style="margin-top: -25%">
            <div class="demo-input-suffix" style="text-align: center;margin-bottom: 5%;">
              用户名：
              <el-input
                placeholder="请输入用户名"
                v-model="rName" style="width: 50%">
              </el-input>
            </div>
          </div>
          <div>
            <div class="demo-input-suffix" style="text-align: center;margin-left: 5%;margin-bottom: 5%;">
              密码：
              <el-input
                placeholder="请输入密码"
                v-model="rPass1" style="width: 53%" :show-password="true">
              </el-input>
            </div>
          </div>
          <div>
            <div class="demo-input-suffix" style="text-align: center;margin-left: 0%;margin-bottom: 7%;">
              再次确认:
              <el-input
                placeholder="请再次输入密码"
                v-model="rPass2" style="width: 53%" :show-password="true">
              </el-input>
            </div>
          </div>
          <el-button @click="registerClose">取 消</el-button>
          <el-button type="primary" @click="adduser">确 定</el-button>
        </div>
      </el-dialog>
    </div>
    <div v-show="activeKey===2">
      <el-dropdown >
        <el-button>
          {{user.name}}<i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item ><div @click="goTo(1)">个人信息</div> </el-dropdown-item>
          <el-dropdown-item>
            <div @click="restart">退出</div>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
  </div>
  </div>
</div>
</template>

<script>
export default {
name: "welcome",
  inject:['reload'],
  props:['titleMessage'],
  data(){
    return {

      dialogVisible2:false,
      input1: '',
      input2:'',
      rName:'',
      rPass1:'',
      rPass2:'',
      message:"登录",
      activeKey:1,
      dialogVisible: false,
      user:this.$root.user
    }
  },
  methods:{
    registerClose(){
      this.dialogVisible2 = false
      this.rName='';
      this.rPass1='';
      this.rPass2='';
    },
    loginClose(){
      this.dialogVisible = false
      this.input1 = ''
      this.input2 = ''
    },
    clickLogin(){
      this.dialogVisible = true;
      this.$emit('getClick',true);
    },
    clickRegister(){
      this.dialogVisible2 = true;
      this.$emit('getClick',true);
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    adduser(){
      var _this = this;
      var _name = _this.rName
      var _password = _this.rPass1;
      if (_name=='')
        _this.$message.error('用户名不能为空');
      else if (_password=='')
        _this.$message.error('密码形式不正确')
      else if (_password!=_this.rPass2){
        _this.$message.error('两次密码不同');
      }
      else {
        var check = false
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
        console.log(_date1)
        _this.$http.get('/api/users/check',{params:{name:_name}}).then(
          (response)=>{
              if (response.data.length>0){
                check = false
              }else
                check = true
            this.send(check)
            console.log(response.data)
            console.log(check)
          }
        )
      }

    },
    send(check){
      var _this = this;
      var _name = _this.rName
      var _password = _this.rPass1;
      var _date = new Date();
      const moment = require('moment')
      var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
      if (check==true){
        this.$http.post('/api/users/addUser', {
          name: _name,
          password: _password,
          date: _date1
        },{}).then((response) => {
          console.log(response.statusText);
        })
        _this.dialogVisible2 = false
        this.$set(this.user,"name",_name)
        this.$root.user = this.user
        this.$store.commit('getUser',this.user.name)
        this.dialogVisible = false
        this.activeKey = 2
        _this.$message.success('注册成功')
        this.$http.post('/api/users/createUinfo',{
          name:_name
        },{})
      }else
      {
        _this.rName = ''
        _this.rPass1 = ''
        _this.rPass2 = ''
        _this.$message.error('用户名已被注册，请您重新注册账号')
      }

    },
    restart(){
      this.reload();
    },
    login(){
      var _name = this.input1
      var _password = this.input2
      this.$http.get('/api/users/login',
        {params:{
          name:_name,
            password: _password
          }}
      ).then((response) => {
        console.log(response.data);
        if (response.data.length==0){
          this.open()
        }else {
          this.$message.success('登录成功')
          this.$set(this.user,"name",response.data[0].UserName)
          this.$root.user = this.user
          this.$store.commit('getUser',this.user.name)
          this.dialogVisible = false
          this.activeKey = 2
        }
      })
    },
    open() {
      this.input2 = ''
      this.input1 = ''
      this.$message.error('用户或密码错误，请重新输入')
    },
    goTo(id){
      if(id==1){
        this.$router.push({path:'/User'})
      }else if (id==2){
        this.$router.push({path:'/MaoZhuaCao'})
      } else if (id==3){
        this.$router.push({path:'/TianNanXing'})
      }
    }
  },
  mounted() {
    var _this = this;
    if (_this.$root.user.name!=''){
      _this.activeKey = 2;
      this.dialogVisible = false
    }

  }

}
</script>

<style scoped>
.login{
  position: absolute;
  top: 1%;
  right: 1%;
}
.welText{
  margin-top: 4%;
  margin-left: 5%;
}
</style>
