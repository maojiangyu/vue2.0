<template>
  <div>
    <el-container style="width: 100%">
      <el-header>
        <h2 style="color: #a1a1a1;text-align: center;margin-top: 0%">猫爪草</h2>
      </el-header>

      <el-main>
        <div>
          <div style="font-weight: bolder">【中药名】</div>
          <div style="margin-left: 23%">猫爪草 maozhaocao</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【别名】</div>
          <div style="margin-left: 19%">三散草、黄花草、猫爪儿草。</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【英文名】</div>
          <div style="margin-left: 23%">Radix Rnunculi Ternati</div>

        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【来源】</div>
          <div style="margin-left: 19%">毛茛科植物小毛茛的干燥块根。</div>

        </div>
        <div v-html="form"></div>
        <div v-html="location"></div>
        <div v-html="effect"></div>
        <div style="margin-top: 10%;margin-left: 45%">
          <el-button-group>
            <el-button icon="el-icon-edit" style="width: 45%;background: #beefad" @click="writeCommont">评论</el-button>
            <el-button icon="el-icon-star-off" style="width: 45%;margin-left: 5%;background: #d6efad" @click="addMC">收藏</el-button>
          </el-button-group>

        </div>
      </el-main>
      <el-drawer
        :visible.sync="drawer"
        :direction="direction"
        ref="drawerBar"
        size="40%" >
        <div style="text-align: center">
          <el-input
            type="textarea"
            placeholder="请输入内容"
            v-model="MComment"
            maxlength="40"
            :rows="5"
            show-word-limit style="width: 80%;margin-top: -5%" ref="MCC">
          </el-input>
        </div>

        <el-button-group style="margin-top: 5%;margin-left: 50%">
          <el-button style="background: #91C788;border: none" @click="submitMC">发表</el-button>
          <el-button style="left: 15%" @click="handleClose2">取消</el-button>
        </el-button-group>
      </el-drawer>
    </el-container>
    <div style="margin-top: 5%">
      <div v-show="CommentList.length>0">
        <div v-for="item in CommentList" style="margin-top: 10%">
          <el-rate
            v-model="item.value1" style="margin-left: 60%">
          </el-rate>
          <div>{{item.user}}</div>
          <div style="margin-top: 10%">{{item.comment}}</div>
          <div style="margin-left: 60%;margin-top: 5%">{{item.data}}</div>
        </div>
      </div>
    </div>
    <el-drawer
      title="我是标题"
      :direction="direction2"
      :visible.sync="drawer2"
      size="15%"
      :with-header="false">
      <div style="position: relative;top: 10%;right: 10%">
        <welcome></welcome>
      </div>

    </el-drawer>
  </div>
</template>

<script>
import Welcome from "../welcome";
export default {
  name: "MaoZhuaCao",
  components: {Welcome},
  data(){
    return {
      form:'<div style="margin-top: 10%"><div style="font-weight: bolder">【植物形态】</div><div style="margin-left: 28%">多年生草本。块根数个，近纺锤</div>' +
        '</div><div style="margin-top: 10%">形，顶端质硬，形似猫爪。茎细弱，高5～17</div>' +
        '<div style="margin-top: 10%">厘米，疏生短柔毛，毛。叶互生，叶片宽卵形</div>' +
        '<div style="margin-top: 10%">或三角状宽卵形，长3后渐无毛。基生叶丛生</div>' +
        '<div style="margin-top: 10%">，有长柄，三出复叶或3深裂，小叶片卵圆形</div>' +
        '<div style="margin-top: 10%">或阔倒卵形，长0.5～1.5厘米，宽0.5～1厘</div>' +
        '<div style="margin-top: 10%">米，先端3浅裂或齿裂，基部楔形，中央1片</div>' +
        '<div style="margin-top: 10%">小叶较大；茎生叶互生，通常无柄，3裂，裂</div>' +
        '<div style="margin-top: 10%">片线形。花单生于枝端，直径约1.5厘米；花</div>' +
        '<div style="margin-top: 10%">梗长0.5～2厘米，有短柔毛；萼片5，长圆形</div>' +
        '<div style="margin-top: 10%">或倒卵形，绿色，外面疏生柔毛；花瓣5，也</div>' +
        '<div style="margin-top: 10%">有6～8，阔倒卵形，黄色，无毛，基部有袋</div>' +
        '<div style="margin-top: 10%">状蜜腺；雄蕊多数，花丝扁平，花药长圆形；</div><div style="margin-top: 10%">雌蕊多数，丛集于膨大的花托上，柱头短。聚</div>' +
        '<div style="margin-top: 10%">合果球形，瘦果卵形，表面淡棕色，平滑，有</div><div style="margin-top: 10%">短而稍弯的果喙。花期5月，果期5～6月。</div>',
      location:'<div style="margin-top: 10%"><div style="font-weight: bolder">【产地分布】</div><div style="margin-left: 28%">生于田边、路旁、洼地及山坡草</div>' +
        '</div><div style="margin-top: 10%">丛中。主产于河南，江苏、浙江、湖北等地</div><div style="margin-top: 10%">亦产。</div>',
      effect:'<div style="margin-top: 10%"><div style="font-weight: bolder">【功效与作用】</div><div style="margin-left: 32%">散结、解毒、消肿。属化痰止</div>' +
        '</div><div style="margin-top: 10%">咳平喘药下属分类的温化寒痰药。</div>',
      drawer: false,
      direction: 'btt',
      MComment:'',
      CommentList:[],
      drawer2: false,
      direction2: 'btt',
    }
  },
  methods: {
    addMC(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后收藏')
      }else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
        this.$http.post('/api/users/addCC',{
          name:this.$store.state.user,
          MID:'2'
        }).then((response) => {
          console.log(response.statusText);
        })
      }


    },
    handleClose(done) {
      this.$confirm('确认放弃评论吗？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    handleClose2(){
      this.$refs.drawerBar.closeDrawer()
    },
    writeCommont(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后评论')
      }else {
        _this.drawer = true
      }
    },
    submitMC(){
      var _this = this;
      var comment = _this.MComment
      var _name = _this.$root.user.name
      if (comment=='')
        _this.$message.error('输入内容不能为空')
      else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm')
        this.$http.post('/api/users/addMC', {
          name: _name,
          MID:'2',
          MC:comment,
          date: _date1
        },{}).then((response) => {
          console.log(response.statusText);
          _this.MComment = '';
          _this.$message.success('发表成功')
          _this.getList()
          _this.drawer = false
        })
      }

    },
    getList(){
      var _this = this;
      var _name = _this.$root.user.name
      this.$http.get('/api/users/getComment1',{params:{
          name:_name,
          id:'2'
        }}).then((reponse)=>{
        _this.CommentList = []
        var temp;
        const moment = require('moment')
        for (let i = 0 ; i < reponse.data.length; i ++){
          temp = {
            comment:'',
            data:'',
            user:'',
            value1:null
          }
          temp.comment = reponse.data[i].MedicineC
          temp.user = reponse.data[i].UserName
          var _date1 = moment(reponse.data[i].MCDate).format('MM-DD HH:mm')
          temp.data = _date1
          _this.CommentList.push(temp)
        };
        console.log(_this.CommentList)
      })
    }
  },
  mounted() {
    this.getList();
    console.log(this.ListKey)
  },
}
</script>

<style scoped>
.el-header, .el-footer {
  background-color: #b8ffc5;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #c6ffa6;
  color: #333;
  text-align: center;
  border-radius: 5px
}

.el-main {
  background-color: #f7fcff;
  color: #333;
  line-height: 5%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>
