<template>
  <div>
    <el-container style="width: 100%">
      <el-header>
        <h2 style="color: #a1a1a1;text-align: center;margin-top: 0%">华山参</h2>
      </el-header>

      <el-main>
        <div>
          <div style="font-weight: bolder">【中药名】</div>
          <div style="margin-left: 23%">华山参 huashanshen</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【别名】</div>
          <div style="margin-left: 19%">热参、白毛参、秦参。</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【英文名】</div>
          <div style="margin-left: 23%">Physochlainae Radix</div>

        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【来源】</div>
          <div style="margin-left: 19%">茄科植物漏斗泡囊草的根。</div>

        </div>
        <div v-html="form"></div>
        <div v-html="location"></div>
        <div v-html="effect"></div>
        <div style="margin-top: 10%;margin-left: 45%">
          <el-button-group>
            <el-button icon="el-icon-edit" style="width: 45%;background: #beefad" @click="writeCommont">评论</el-button>
            <el-button icon="el-icon-star-off" style="width: 45%;margin-left: 5%;background: #d6efad" @click="addMC">收藏</el-button>
          </el-button-group>

        </div>
      </el-main>
      <el-drawer
        :visible.sync="drawer"
        :direction="direction"
        ref="drawerBar"
      size="40%" >
        <div style="text-align: center">
          <el-input
            type="textarea"
            placeholder="请输入内容"
            v-model="MComment"
            maxlength="40"
            :rows="5"
            show-word-limit style="width: 80%;margin-top: -5%" ref="MCC">
          </el-input>
        </div>

        <el-button-group style="margin-top: 5%;margin-left: 50%">
          <el-button style="background: #91C788;border: none" @click="submitMC">发表</el-button>
          <el-button style="left: 15%" @click="handleClose2">取消</el-button>
        </el-button-group>
      </el-drawer>
    </el-container>
    <div style="margin-top: 5%;">
      <div v-show="CommentList.length>0">
        <div v-for="item in CommentList" style="margin-top: 10%" :key="item.id">
          <el-rate
            v-model="item.value1" style="margin-left: 60%">
          </el-rate>
          <div >
            {{item.user}}
          </div>
          <div style="margin-top: 10%;">{{item.comment}}</div>
          <div style="margin-left: 60%;margin-top: 5%">{{item.data}}</div>
        </div>
      </div>
    </div>
    <el-drawer
      title="我是标题"
      :direction="direction2"
      :visible.sync="drawer2"
      size="15%"
      :with-header="false">
      <div style="position: relative;top: 10%;right: 10%">
        <welcome></welcome>
      </div>

    </el-drawer>
  </div>

</template>

<script>
import Welcome from "../welcome";
export default {
  name: "HuaShanShen",
  components: {Welcome},
  data(){
    return {
      form:'<div style="margin-top: 10%"><div style="font-weight: bolder">【植物形态】</div><div style="margin-left: 28%">多年生草本，高20～60厘米。根</div>' +
        '</div><div style="margin-top: 10%">圆锥状，肉质。茎单一或分枝，被白色腺质柔</div>' +
        '<div style="margin-top: 10%">毛。叶互生，叶片宽卵形或三角状宽卵形，长</div>' +
        '<div style="margin-top: 10%">3～9厘米，宽4～9厘米，先端钝或急尖，基</div>' +
        '<div style="margin-top: 10%">部楔形下延，有时近截形，全缘或微波状。伞</div>' +
        '<div style="margin-top: 10%">房状聚伞花序，顶生或腋生，绿黄色。花萼筒</div>' +
        '<div style="margin-top: 10%">状钟形，5中裂，花后增大成漏斗状；花冠漏</div>' +
        '<div style="margin-top: 10%">斗状钟形，长约1厘米，5浅裂；雄蕊5枚，稍</div>' +
        '<div style="margin-top: 10%">不等长，着生于花冠筒中部；花盘垫座状；子</div>' +
        '<div style="margin-top: 10%">房近球形，2室，花柱丝状，与花冠近等长，</div>' +
        '<div style="margin-top: 10%">柱头2浅裂。蒴果近球形，有宿萼；种子多数</div>' +
        '<div style="margin-top: 10%">，扁肾形。花期3～4月，果期4～6月。</div>',
      location:'<div style="margin-top: 10%"><div style="font-weight: bolder">【产地分布】</div><div style="margin-left: 28%">生于海拔400～1600米的山谷、</div>' +
        '</div><div style="margin-top: 10%">山坡草地或林下。分布于河南、山西、陕西等</div>' +
        '<div style="margin-top: 10%">地。</div>',
      effect:'<div style="margin-top: 10%"><div style="font-weight: bolder">【功效与作用】</div><div style="margin-left: 32%">平喘止咳、安神镇惊。属化痰</div>' +
        '</div><div style="margin-top: 10%">止咳平喘药下属分类的温化寒痰药。</div>',
      drawer: false,
      direction: 'btt',
      MComment:'',
      CommentList:[],
      drawer2: false,
      direction2: 'btt',
    }
  },
  methods: {
    getDrawer2(val){
      this.drawer2 = val;
    },
    addMC(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后收藏')
        _this.drawer2=true
      }else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
        this.$http.post('/api/users/addCC',{
          name:this.$store.state.user,
          MID:'1'
        }).then((response) => {
          console.log(response.statusText);

        })
      }


    },
    handleClose(done) {
      this.$confirm('确认放弃评论吗？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    handleClose2(){
      this.$refs.drawerBar.closeDrawer()
    },
    writeCommont(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后评论')
        _this.drawer2 = true
      }else {
        _this.drawer = true
      }
    },
    submitMC(){
      var _this = this;
      var comment = _this.MComment
      var _name = _this.$root.user.name
      if (comment=='')
        _this.$message.error('输入内容不能为空')
      else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm')
        this.$http.post('/api/users/addMC', {
          name: _name,
          MID:'1',
          MC:comment,
          date: _date1
        },{}).then((response) => {
          console.log(response.statusText);
          _this.MComment = '';
          _this.$message.success('发表成功')
          _this.getList()
          _this.drawer = false
        })
      }

    },
    getList(){
      var _this = this;
      var _name = _this.$root.user.name
      this.$http.get('/api/users/getComment1',{params:{
          name:_name,
          id:'1'
        }}).then((reponse)=>{
          _this.CommentList = []
        var temp;
          const moment = require('moment')
          for (let i = 0 ; i < reponse.data.length; i ++){
            temp = {
              id:i,
              comment:'',
              data:'',
              user:'',
              value1:null
            }
            temp.comment = reponse.data[i].MedicineC
            temp.user = reponse.data[i].UserName
            var _date1 = moment(reponse.data[i].MCDate).format('MM-DD HH:mm')
            temp.data = _date1
            _this.CommentList.push(temp)
          };
          console.log(_this.CommentList)
      })
    },
    getValue(item){
      item.value1 = item.value1
    }
  },
  mounted() {
    this.getList();
  },
}
</script>

<style scoped>
.el-header, .el-footer {
  background-color: #b8ffc5;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #c6ffa6;
  color: #333;
  text-align: center;
  border-radius: 5px
}

.el-main {
  background-color: #f7fcff;
  color: #333;
  line-height: 5%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>
