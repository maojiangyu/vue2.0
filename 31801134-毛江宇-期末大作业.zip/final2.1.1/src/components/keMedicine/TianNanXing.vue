<template>
  <div>
    <el-container style="width: 100%">
      <el-header>
        <h2 style="color: #a1a1a1;text-align: center;margin-top: 0%">天南星</h2>
      </el-header>

      <el-main>
        <div>
          <div style="font-weight: bolder">【中药名】</div>
          <div style="margin-left: 23%">天南星 tiannanxing</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【别名】</div>
          <div style="margin-left: 19%">山苞米、独脚莲、蛇包谷</div>
        </div>
        <div style="margin-top: 10%">
          <div style="font-weight: bolder">【英文名】</div>
          <div style="margin-left: 23%">Arisaematis Rhizoma</div>

        </div>
        <div v-html="form"></div>
        <div v-html="location"></div>
        <div v-html="effect"></div>
        <div style="margin-top: 10%;margin-left: 45%">
          <el-button-group>
            <el-button icon="el-icon-edit" style="width: 45%;background: #beefad" @click="writeCommont">评论</el-button>
            <el-button icon="el-icon-star-off" style="width: 45%;margin-left: 5%;background: #d6efad" @click="addMC">收藏</el-button>
          </el-button-group>

        </div>
      </el-main>
      <el-drawer
        :visible.sync="drawer"
        :direction="direction"
        ref="drawerBar"
        size="40%" >
        <div style="text-align: center">
          <el-input
            type="textarea"
            placeholder="请输入内容"
            v-model="MComment"
            maxlength="40"
            :rows="5"
            show-word-limit style="width: 80%;margin-top: -5%" ref="MCC">
          </el-input>
        </div>

        <el-button-group style="margin-top: 5%;margin-left: 50%">
          <el-button style="background: #91C788;border: none" @click="submitMC">发表</el-button>
          <el-button style="left: 15%" @click="handleClose2">取消</el-button>
        </el-button-group>
      </el-drawer>
    </el-container>
    <div style="margin-top: 5%">
      <div v-show="CommentList.length>0">
        <div v-for="item in CommentList" style="margin-top: 10%">
          <el-rate
            v-model="item.value1" style="margin-left: 60%">
          </el-rate>
          <div>{{item.user}}</div>
          <div style="margin-top: 10%">{{item.comment}}</div>
          <div style="margin-left: 60%;margin-top: 5%">{{item.data}}</div>
        </div>
      </div>
    </div>
    <el-drawer
      title="我是标题"
      :direction="direction2"
      :visible.sync="drawer2"
      size="15%"
      :with-header="false">
      <div style="position: relative;top: 10%;right: 10%">
        <welcome></welcome>
      </div>

    </el-drawer>
  </div>
</template>

<script>
import Welcome from "../welcome";
export default {
  name: "TianNanXing",
  components: {Welcome},
  data(){
    return {
      form:'<div style="margin-top: 10%"><div style="font-weight: bolder">【植物形态】</div><div style="margin-left: 28%">多年生草本。块茎扁球形。叶1</div>' +
        '</div><div style="margin-top: 10%">片，稀2片，叶柄长达70厘米，绿色，叶片放</div>' +
        '<div style="margin-top: 10%">射分裂，裂片7～20，无柄，披针形、长圆形</div>' +
        '<div style="margin-top: 10%">至椭圆形，先端长渐尖，成线形长尾，尾长7</div>' +
        '<div style="margin-top: 10%">厘米，基部狭窄，上面深绿色，下面粉绿色。</div>' +
        '<div style="margin-top: 10%">花单性，雌雄异株，无花被，肉穗花序由叶柄</div>' +
        '<div style="margin-top: 10%">鞘部抽出，具褐色斑纹；佛焰苞绿色，展开部</div>' +
        '<div style="margin-top: 10%">分外卷，然后扩大成檐部，先端渐窄呈线形尾</div>' +
        '<div style="margin-top: 10%">状；雄花序长2～2.5厘米，花密，雄蕊2～4</div>' +
        '<div style="margin-top: 10%">；雌花序长约2厘米，下部常具钻形中性花。</div>' +
        '<div style="margin-top: 10%">浆果红色。花期5～7月，果期8～9月。</div>',
      location:'<div style="margin-top: 10%"><div style="font-weight: bolder">【产地分布】</div><div style="margin-left: 28%">生于林下、灌丛中阴湿地。分布</div>' +
        '</div><div style="margin-top: 10%">于东北及山东等地。</div>' ,
      effect:'<div style="margin-top: 10%"><div style="font-weight: bolder">【功效与作用】</div><div style="margin-left: 32%">燥湿化痰、祛风止痉、散结消</div>' +
        '</div><div style="margin-top: 10%">肿。属化痰止咳平喘药下属分类的温化寒痰</div><div style="margin-top: 10%">药。</div>',
      drawer: false,
      direction: 'btt',
      MComment:'',
      CommentList:[],
      drawer2: false,
      direction2: 'btt',
    }
  },
  methods: {
    handleClose(done) {
      this.$confirm('确认放弃评论吗？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    handleClose2(){
      this.$refs.drawerBar.closeDrawer()
    },
    writeCommont(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后评论')
      }else {
        _this.drawer = true
      }
    },
    submitMC(){
      var _this = this;
      var comment = _this.MComment
      var _name = _this.$root.user.name
      if (comment=='')
        _this.$message.error('输入内容不能为空')
      else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm')
        this.$http.post('/api/users/addMC', {
          name: _name,
          MID:'3',
          MC:comment,
          date: _date1
        },{}).then((response) => {
          console.log(response.statusText);
          _this.MComment = '';
          _this.$message.success('发表成功')
          _this.getList()
          _this.drawer = false
        })
      }

    },
    addMC(){
      var _this = this;
      if(_this.$root.user.name==''){
        _this.$message.error('请登录后收藏')
      }else {
        var _date = new Date();
        const moment = require('moment')
        var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
        this.$http.post('/api/users/addCC',{
          name:this.$store.state.user,
          MID:'3'
        }).then((response) => {
          console.log(response.statusText);
        })
      }


    },
    getList(){
      var _this = this;
      var _name = _this.$root.user.name
      this.$http.get('/api/users/getComment1',{params:{
          name:_name,
          id:'3'
        }}).then((reponse)=>{
        _this.CommentList = []
        var temp;
        const moment = require('moment')
        for (let i = 0 ; i < reponse.data.length; i ++){
          temp = {
            comment:'',
            data:'',
            user:'',
            value1:null
          }
          temp.comment = reponse.data[i].MedicineC
          temp.user = reponse.data[i].UserName
          var _date1 = moment(reponse.data[i].MCDate).format('MM-DD HH:mm')
          temp.data = _date1
          _this.CommentList.push(temp)
        };
        console.log(_this.CommentList)
      })
    }
  },
  mounted() {
    this.getList();
  },
}
</script>

<style scoped>
.el-header, .el-footer {
  background-color: #b8ffc5;
  color: #ffffff;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #c6ffa6;
  color: #333;
  text-align: center;
  border-radius: 5px
}

.el-main {
  background-color: #f7fcff;
  color: #333;
  line-height: 5%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
</style>
