<template>
  <div>
    <el-container style="width: 100%">
      <el-header>
        <h2 style="color: #a1a1a1;text-align: center;margin-top: 0">人体穴位大全</h2>
      </el-header>

      <el-main>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
        <el-row :gutter="2" style="background: #e4f1ea;height: 100px">
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              阳溪
            </p>
            <p>臑俞穴，在臂内收，</p>
            <p>腋后纹头直上，肩胛</p>
            <p>冈下缘凹陷中。</p>
          </el-col>
          <el-col :span="12">
            <p style="font-weight: bolder;font-size: x-large">
              足窍阴
            </p>
            <p>足窍阴穴，在足第4趾</p>
            <p>末节外侧，距趾甲角0.</p>
            <p>1寸(指寸)。</p>
          </el-col>
        </el-row>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
name: "XueWei"
}
</script>

<style scoped>
.el-row {
  margin-bottom: 20px}
.el-row:last-child {
   margin-bottom: 0;
}
.el-col {
  border-radius: 4px;
}
.bg-purple-dark {
  background: #99a9bf;
}
.bg-purple {
  background: #d3dce6;
}
.bg-purple-light {
  background: #e5e9f2;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}
</style>
