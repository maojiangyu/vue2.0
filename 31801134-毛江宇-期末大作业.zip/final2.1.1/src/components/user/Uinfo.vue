<template>
<div>
  <div>
    <el-container>
      <el-button @click="drawer = true" icon="el-icon-s-unfold" style="background: #d1dcd2;color: #ffffff;">
      </el-button>
      <div class="login">
        <div>
          <el-dropdown >
            <el-button style="font-size: larger">
              {{user.name}}<i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item ><div @click="goTo(1)">个人信息</div> </el-dropdown-item>
              <el-dropdown-item>
                <div @click="restart">退出</div>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </el-container>
    <el-main>
      <div v-show="Key===1">
        <div style="font-weight: bolder">账号</div>
        <div style="margin-top: 20%">昵称</div>
        <div style="margin-left: 20%;font-size: larger">{{user.name}}</div>
        <div style="margin-top: 20%">注册时间</div>
        <div style="margin-top: 18%;font-size: larger">{{createDate}}</div>
      </div>
      <div v-show="Key===2">
        <div style="font-weight: bolder">个人信息</div>
        <div style="margin-top: 20%">性别</div>
        <div style="margin-top: 5%"><el-select v-model="sex" slot="prepend" placeholder="请选择">
          <el-option label="男" value="1"></el-option>
          <el-option label="女" value="2"></el-option>
          <el-option label="保密" value="3"></el-option>
        </el-select></div>
        <div style="margin-top: 10%">手机号</div>
        <el-input
          placeholder="电话号"
          v-model="phone"
          clearable style="margin-top: 5%">
        </el-input>
        <div style="margin-top: 10%">姓名</div>
        <div class="demo-input-suffix" style="margin-top: 5%">
          <el-input
            placeholder="性"
            style="width: 40%"
            v-model="xin">
          </el-input>
          <el-input
            placeholder="名"
            style="width: 40%"
            v-model="ming" >
          </el-input>
        </div>
        <div style="margin-top: 10%">邮箱</div>
        <el-input
          placeholder="邮箱"
          v-model="Email"
          clearable style="margin-top: 5%">
        </el-input>
        <div style="margin-top: 10%;text-align: center">
          <el-button style="background: #d1dcd2;color: white" @click="setUserInfo">保存</el-button>
        </div>
      </div>
      <div v-show="Key===3">
        <div>
          <el-table
            :data="zhikeList"
            style="width: 100%">
            <el-table-column
              prop="name"
              label="药材名"
              width="90">
            </el-table-column>
            <el-table-column
              prop="effect"
              label="功效"
              width="180">
            </el-table-column>
            <el-table-column label="">
              <template slot-scope="scope">
                <el-button
                  size="mini"
                  type="danger"
                  @click="handleDelete(scope.$index, scope.row)">取消收藏</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </el-main>
    </div>
    <el-drawer
      :visible.sync="drawer"
      :with-header="false" direction="ltr" size="60%">
      <el-col :span="24">
        <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          @open="handleOpen()"
          @close="handleClose1" active-text-color="#91C788">
          <el-menu-item index="1" @click="goTo(1)">
            <i class="el-icon-s-home"></i>
            <span slot="title" >首页</span>
          </el-menu-item>
          <el-menu-item index="2" @click="goTo(2)">
            <i class="el-icon-menu"></i>
            <span slot="title" >账号</span>
          </el-menu-item>
          <el-menu-item index="3" @click="goTo(3)">
            <i class="el-icon-document"></i>
            <span slot="title" >个人信息</span>
          </el-menu-item>
          <el-menu-item index="4" @click="goTo(4)">
            <i class="el-icon-star-on"></i>
            <span slot="title" >我的收藏</span>
          </el-menu-item>
        </el-menu>
      </el-col>
    </el-drawer>
</div>

</template>

<script>
export default {
name: "information",
  inject:['reload'],
  data(){
    return {
      createDate:'',
      Email:'',
      xin:'',
      ming:'',
      sex:'',
      phone:'',
      input1: '',
      input2:'',
      message:"登录",
      activeKey:1,
      Key:1,
      dialogVisible: false,
      user:this.$root.user,
      drawer:false,
      zhikeList:[
        {
          id:1,
          name:'华山参',
          effect:'平喘止咳、安神镇惊。属化痰'
        },
        {
          id:2,
          name:'猫爪草',
          effect:'散结、解毒、消肿。属化痰止咳'
        },
        {
          id:3,
          name:'天南星',
          effect:'散结、解毒、消肿。属化痰止咳'
        },
        {
          id:4,
          name:'海浮石',
          effect:'散结、解毒、消肿。属化痰止咳'
        }
      ],
    }
  },
  methods:{
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    getUserInfo(){
      this.$http.get('/api/users/getUINFO',
        {params:{
            name:this.$store.state.user
          }}
      ).then(reps=>{
        console.log(reps)
        this.ming = reps.body[0].name;
        this.xin = reps.body[0].xin;
        this.Email = reps.body[0].email;
        this.sex = reps.body[0].sex;
        this.phone = reps.body[0].phone;

      })
    },
    setUserInfo(){
      this.$http.post('/api/users/setUinfo',
        {
          name:this.$store.state.user,
          sex:this.sex,
          phone:this.phone,
          ming:this.ming,
          xin:this.xin,
          email:this.Email
        }
      )
    },
    getMedicineList(){
      this.zhikeList = []
      this.$http.get('/api/users/getCC',
        {params:{
            name:this.$store.state.user
          }}
      ).then(reps=>{
        var medicineList = []
        for (let i = 0;i < reps.data.length;i++){
          var temp = {
            id:''
          }
          temp.id = reps.data[i].Mid;
          medicineList.push(temp);
        }
        for (let i = 0 ; i < medicineList.length;i ++)
          this.getZhiKe(medicineList[i]);
      })
    },
    getZhiKe(item){
      this.$http.get('/api/users/getM',
        {params:{
            id:item.id,
          }}
      ).then(reps=>{
        var temp = {}
        temp.name = reps.data[0].MName
        temp.id = reps.data[0].Mid
        temp.effect = reps.data[0].effect
        this.zhikeList.push(temp)
      })
    },
    adduser(){
      var _name = 'mjy'
      var _password = '31801134'
      var _date = new Date();
      const moment = require('moment')
      var _date1 = moment(_date).format('YYYY-MM-DD HH:mm:ss')
      console.log(_date1)
      this.$http.post('/api/users/addUser', {
        name: _name,
        password: _password,
        date: _date1
      },{}).then((response) => {
      })
    },
    restart(){
      this.reload();
      this.$router.push({path:'/'})
    },
    login(){
      var _name = this.input1
      var _password = this.input2
      this.$http.get('/api/users/login',
        {params:{
            name:_name,
            password: _password
          }}
      ).then((response) => {
        console.log(response.data);
        if (response.data.length==0){
          this.open()
        }else {
          this.$message.success('登录成功')
          this.$set(this.user,"name",response.data[0].UserName)
          this.$root.user = this.user
          this.dialogVisible = false
          this.activeKey = 2
          this.$store.commit('getUser',this.user.name)
        }
      })
    },
    open() {
      this.input2 = ''
      this.input1 = ''
      this.$message.error('密码错误，请重新输入')
    },
    goTo(id){
      if(id==1){
        this.$router.push({path:'/'})
      }else if (id==2){
        this.Key = 1;
        this.drawer = false
      }else if (id==3){
        this.getUserInfo()
        this.Key = 2;
        this.drawer = false
      }else if (id==4){
        this.Key = 3;
        this.drawer = false
      }
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose1(key, keyPath) {
      console.log(key, keyPath);
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(row)
      var _name = this.$store.state.user
      this.$http.post('/api/users/deleteM',
        {
            name:_name,
            MID:row.id
          }
      ).then(reps=>{
        this.$message.success('已取消收藏')
        this.getMedicineList();
      })
    }
  },
  mounted() {
    var _this = this;
    if (_this.$root.user.name!=''){
      _this.activeKey = 2;
      this.dialogVisible = false
    }
    this.getMedicineList();
    this.getUserInfo()
    _this.$http.get('/api/users/check',{params:{name:this.$store.state.user}})
    .then(reps=>{
      const moment = require('moment')
      var _date1 = moment(reps.data[0].CreateDate).format('YYYY-MM-DD')
      _this.createDate = _date1
    })
  }

}
</script>

<style scoped>
.login{
  position: absolute;
  right: 1%;
}
.welText{
  margin-top: 4%;
  margin-left: 5%;
}
</style>
