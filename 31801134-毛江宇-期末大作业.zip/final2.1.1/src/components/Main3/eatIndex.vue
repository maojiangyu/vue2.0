<template>
<div>
  <el-container>
    <el-container>
      <el-main style="background: #efffeb">
        <div style="text-align: center;margin-top: 0%">
          <h3>中医菜谱</h3>
        </div>
        <div style="margin-top: 10%">
          <el-collapse v-model="activeName" accordion>
            <el-collapse-item name="1">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">薏米拌黄瓜</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】薏米20克。</p>
                <p>【食材】黄瓜2，香油5毫升，生抽8毫升，盐3克，鸡精2克。</p>
                <p>【做法】</p>
                <p>步骤1：黄瓜洗净，切成条，放入盆中加盐腌渍20分钟；薏米淘洗干净，泡透捞出，沥干水分，放入锅中煮熟，捞出沥干水分。</p>
                <p>步骤2：小黄瓜洗去盐水，放入薏米，加入香油、生抽、鸡精，搅拌均匀即可。</p>
                <p>【功效】健脾除湿、美自护肤。</p>
                <p>【食法】佐餐食用。</p>
              </div>
            </el-collapse-item>
            <el-collapse-item name="2">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">羊肝粥</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】枸杞15克，羊肝40克。</p>
                <p>【食材】大米80克，盐3克。</p>
                <p>【做法】</p>
                <p>步骤1：枸杞洗净；羊肝洗净，切块；大米淘洗干净备用。</p>
                <p>步骤2：砂锅置火上，入水适量，放入大米、枸杞、羊肝，大火煮沸转小火熬煮40分钟，加入盐调味即可。</p>
                <p>【功效】补肝肾、明眼目。适宜夜盲症患者食用。</p>
                <p>【食法】每日一次，做早餐食用。</p>
              </div>
            </el-collapse-item>
            <el-collapse-item name="3">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">丁香炖鸡腿</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】丁香、陈皮各8克，党参、白术各10克。</p>
                <p>【食材】鸡腿2只，生姜3克，盐3克。</p>
                <p>【做法】
                </p>
                <p>步骤1：以上药材、鸡腿分别洗净；陈皮清水泡发，鸡腿沸水汆烫备用。</p>
                <p>步骤2：药材放入砂锅，再放上鸡腿，加水盖过，放入姜片，保鲜膜密封，上锅隔水炖2小时，启封后放盐调味即可。</p>
                <p>【功效】健脾养胃、促进消化。适用于肠胃虚寒所致的腹部冷痛、呕吐或拉肚子等症。也可用于孕妇的早孕反应。</p>
                <p>【食法】佐餐食用，吃肉喝汤。</p>
              </div>
            </el-collapse-item>
            <el-collapse-item name="4">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">茯苓天麻蒸鲤鱼</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】茯苓、川芎各8克，天麻15克。</p>
                <p>【食材】鲤鱼1条，料酒10毫升，葱、姜各8克，盐3克，鸡精1克。</p>
                <p>【做法】
                </p>
                <p>步骤1：鲤鱼宰杀后，去鳞、鳃、内脏，洗净血水；茯苓、川芎洗净，切片；天麻清水泡软，切片，放入鲤鱼腹内；葱、姜洗净，切碎。</p>
                <p>步骤2：鲤鱼放入盆中，加姜、葱，适量清水，上笼蒸40分钟，取出盛盘，备用。</p>
                <p>步骤3：砂锅置中火上，入水适量，放入茯苓、川芎，加盐、鸡精调味，煎煮30分钟，捞去药渣，汤汁浇于鱼上即可。</p>
                <p>【功效】活血止痛、平肝熄风。适用于治虚火头痛、眼黑肢麻、神经衰弱、高血压头昏、因风寒湿引起的关节疼痛等症。</p>
                <p>【食法】吃鱼喝汤。</p>
              </div>
            </el-collapse-item>
            <el-collapse-item name="5">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">肉苁蓉粥</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】肉苁蓉6克。</p>
                <p>【食材】羊肉30克、大米80克，盐、姜、葱各3克。</p>
                <p>【做法】
                </p>
                <p>步骤1：肉苁蓉清水洗净；羊肉洗净，切丁；大米淘洗干净；葱、姜洗净，切碎。</p>
                <p>步骤2：砂锅置小火上，入水适量，放入肉苁蓉煎煮40分钟，去渣留汁，加入羊肉、大米同煮至粥黏稠，放入盐、葱、姜调味，即可食用。</p>

                <p>【功效】温肾壮阳、利水消肿。</p>
                <p>【食法】宜早、晚空腹食用。</p>
              </div>
            </el-collapse-item>
            <el-collapse-item name="6">
              <template slot="title"><div style="margin-left: 2%;font-weight: bolder;font-size: larger">山茱萸炖猪腰</div></template>
              <div style="margin-left: 2%;font-size: medium">
                <p>【药材】山茱萸5克。</p>
                <p>【食材】核桃肉8克，猪肾1只，盐2克。</p>
                <p>【做法】
                </p>
                <p>步骤1：猪肾剖开，刮去筋膜和臊腺，洗净；山茱萸、核桃肉洗净，然后装入猪肾中，用棉线捆住。</p>
                <p>步骤2：砂锅置火上，入水适量，放入猪肾，大火煮沸，小火炖1小时，加盐调味即可。</p>
                <p>【功效】补肾涩精。适用于肾虚不固之遗精、早泄、腰痛腿软等症。</p>
                <p>【食法】佐餐食用，吃肉喝汤。</p>
              </div>
            </el-collapse-item>
          </el-collapse>
        </div>
      </el-main>
    </el-container>
  </el-container>
</div>
</template>

<script>
export default {
name: "eatIndex",
  data(){
  return{
    activeName: '1'
  }
  }
}
</script>

<style scoped>

</style>
