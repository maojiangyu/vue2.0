<template>
  <div>
    <div>
      <y-s-info v-bind:message="messageList1"></y-s-info>
    </div>
    <div style="margin-top: 5%;">
      <y-s-info v-bind:message="messageList2"></y-s-info>
    </div>
    <div style="margin-top: 5%;">
    <y-s-info v-bind:message="messageList3"></y-s-info>
  </div>

  </div>
</template>

<script>
import YSInfo from "./YSInfo";
export default {
name: "YMain",
  components: {YSInfo},
  data(){
  return{
    messageList1:{
      id:1,
      title:'养生基础',
      url:require('@/assets/img/YBase.png'),
      data:['疾病发生六阶段','顺天随时'],
      info:',\'中医提升免疫法\',\'中药八招\''
    },
    messageList2:{
      id:2,
      title:'经络养生',
      url:require('@/assets/img/YJ.png'),
      data:['耳按两穴防痴呆','按摩三穴提神'],
      info:',\'多悲忧按摩内关\',\'按揉外劳宫穴\''
    },
    messageList3:{
      id:3,
      title:'运动养生',
      url:require('@/assets/img/YSport.png'),
      data:['踢毽子防病治病','学生谨防中暑'],
      info:',\'面壁蹲墙壮腰腿\',\'处暑之后酷热散\''
    },
  }
  }
}
</script>

<style scoped>

</style>
