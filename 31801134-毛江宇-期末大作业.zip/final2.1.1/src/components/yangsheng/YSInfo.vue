<template>
  <div>
    <el-container style="height: 80px">
      <el-container>
        <el-image :src="message.url" style="width: 40%"></el-image>
        <el-main style="font-size: small;margin-top: -10%;width: 83%;background: #f0ffff">
          <h4 style="margin-left: 25%">{{message.title}}</h4>
            <li style="margin-top: 15%" v-for="item in message.data" :key="item.id">{{item}}</li>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
name: "YSInfo",
  props:['message']
}
</script>

<style scoped>

</style>
