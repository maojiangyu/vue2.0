var Time = {
  getUnix:function(){
    var data = new Date()
    return data.getTime()
  },

  getToDayUnix:function () {
    var date = new Date();
    date.setHours(0)
    date.setMinutes(0);
    date.setMilliseconds(0);
    date.setSeconds(0)
    return date.getTime()
  },

  getYearUnix(){
    var data = new Date()
    data.setMonth(0)
    data.setDate(1)
    data.setHours(0)
    date.setMinutes(0);
    date.setMilliseconds(0);
    date.setSeconds(0)
    return data.getTime()
  },

  getLastDate:function (time) {
    var date = new Date(time)
    var month = data.getMonth()+1<10?'0'+(data.getMonth()+1):date.getMonth()+1
    var day = date.getDate()<10?'0'+date.getDate():date.getDate()
    return date.getFullYear()+'-'+month+"-"+day
  },

  getFormateDate:function (timestamp) {
    var now = this.getUnix();
    var today = this.getToDayUnix();
    var year = this.getYearUnix()
    var timer = (now-timestamp)/1000;
    var tip = ''
    if (timer<=0){
      tip = '刚刚'
    }else if (Math.floor(timer/60)<=0){
      tip = '刚刚'
    }else if (timer < 3600){
      tip = Math.floor(timer/60)+'分钟前'
    }else if (timer >= 3600&&(timestamp-today>=0)){
      tip = Math.floor(timer/60)+'小时前'
    }else if (timer/86400<=31){
      tip = Math.ceil(timer/86400)+'天前'
    }else
      tip = this.getLastDate(timestamp)
    return tip
  }
}

Vue.directive('time',{
  bind:function (el, binding) {
    el.innerHTML = Time.getFormateDate(binding.value);
    el._timeout_=setInterval(function () {
      el.innerHTML = Time.getFormateDate(binding.value)
    })
  },
  unbind:function (el){
    clearInterval(el._timeout_);
    delete el._timeout_;
  }
})
