<template>
  <div id="app">
    <router-view v-if="isRouterAlive"/>
  </div>
</template>

<script>
import Welcome from "./components/welcome";
export default {
  name: 'App',
  provide (){
    return {
      reload:this.reload
    }
  },
  data(){
    return {
      isRouterAlive:true,
      user:{
        user:{
          name: ''
        }
      }
    }
  },
  methods:{
    reload (){
      this.$root.user = {
        name:''
      }
      console.log(this.$root.user)
      this.isRouterAlive = false
      this.$nextTick(function(){
        this.isRouterAlive = true
      })
    }
  },
  components:{
    Welcome
  }
}
</script>
<style>
.el-tabs__item{
  text-align: center;
  font-weight: bolder;
}
.el-tabs__item.is-active{
  color: #91C788 !important
}
.el-tabs__active-bar{
  background-color: #91C788 !important;
}
</style>
