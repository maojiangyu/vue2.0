import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '../components/HelloWorld'
import YMain from "../components/yangsheng/YMain";
import HuaShanShen from "../components/keMedicine/HuaShanShen";
import PopverOne from "../components/firstPopverButton/PopverOne";
import MaoZhuaCao from "../components/keMedicine/MaoZhuaCao";
import TianNanXing from "../components/keMedicine/TianNanXing";
import Uinfo from "../components/user/Uinfo"
import eatIndex from "../components/Main3/eatIndex";
import BaoMaDingXiang from "../components/keMedicine/BaoMaDingXiang";
import HaiFuShi from "../components/keMedicine/HaiFuShi";
import HaiGeKe from "../components/keMedicine/HaiGeKe";

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
      //component:pictureRun
    },
    {
      path:'/HuaShanShen',
      name:'HuaShanShen',
      component:HuaShanShen
    },
    {
      path:'/MaoZhuaCao',
      name:'MaoZhuaCao',
      component:MaoZhuaCao
    },
    {
      path:'/baoMaDingXiang',
      name:'baoMaDingXiang',
      component:BaoMaDingXiang
    },
    {
      path:'/haiFuShi',
      name:'haiFuShi',
      component:HaiFuShi
    },
    {
      path:'/haiGeKe',
      name:'haiGeKe',
      component:HaiGeKe
    },
    {
      path:'/TianNanXing',
      name:'TianNanXing',
      component:TianNanXing
    },
    {
      path:'/User',
      name:'user',
      component:Uinfo
    },
  ]
})
