/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2021/6/5 10:38:13                            */
/*==============================================================*/


drop table if exists CollectionLink;

drop table if exists Comment;

drop table if exists Medicine;

drop table if exists News;

drop table if exists NewsCommont;

drop table if exists User;

/*==============================================================*/
/* Table: CollectionLink                                        */
/*==============================================================*/
create table CollectionLink
(
   UserName             varchar(20) not null,
   Mid                  varchar(10) not null,
   primary key (UserName, Mid)
);

/*==============================================================*/
/* Table: Comment                                               */
/*==============================================================*/
create table Comment
(
   UserName             varchar(20) not null,
   Mid                  varchar(10) not null,
   MedicineC            varchar(20) not null,
   MCDate               date not null,
   CIDone               int not null,
   primary key (UserName, Mid, CIDone)
);

/*==============================================================*/
/* Table: Medicine                                              */
/*==============================================================*/
create table Medicine
(
   Mid                  varchar(10) not null,
   MName                varchar(20) not null,
   primary key (Mid)
);

/*==============================================================*/
/* Table: News                                                  */
/*==============================================================*/
create table News
(
   NewsId               varchar(20) not null,
   NewsName             varchar(20) not null,
   primary key (NewsId)
);

/*==============================================================*/
/* Table: NewsCommont                                           */
/*==============================================================*/
create table NewsCommont
(
   UserName             varchar(20) not null,
   NewsId               varchar(20) not null,
   NewsC                varchar(100) not null,
   NewsDate             date not null,
   CIDtwo               int not null,
   primary key (UserName, NewsId, CIDtwo)
);

/*==============================================================*/
/* Table: User                                                  */
/*==============================================================*/
create table User
(
   UserName             varchar(20) not null,
   password             varchar(20) not null,
   CreateDate           date not null,
   primary key (UserName)
);

alter table CollectionLink add constraint FK_CollectionLink foreign key (UserName)
      references User (UserName) on delete restrict on update restrict;

alter table CollectionLink add constraint FK_CollectionLink2 foreign key (Mid)
      references Medicine (Mid) on delete restrict on update restrict;

alter table Comment add constraint FK_Comment foreign key (UserName)
      references User (UserName) on delete restrict on update restrict;

alter table Comment add constraint FK_Comment2 foreign key (Mid)
      references Medicine (Mid) on delete restrict on update restrict;

alter table NewsCommont add constraint FK_NewsCommont foreign key (UserName)
      references User (UserName) on delete restrict on update restrict;

alter table NewsCommont add constraint FK_NewsCommont2 foreign key (NewsId)
      references News (NewsId) on delete restrict on update restrict;

